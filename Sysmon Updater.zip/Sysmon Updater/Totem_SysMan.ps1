﻿<#  

Sysmon Management

------>>>>!!!READ THIS FIRST!!!<<<<------------------------->>>>!!!READ THIS FIRST!!!<<<<--------------------------------------->>>>!!!READ THIS FIRST!!!<<<<--------------------


TLDR:
Do your homework on this script before using it.

This script is inteded for use with Sysmon provided as freeware from microsoft sysinternals GitHub.  
It is provided with no warranty and in no way guarantees function.  
Script is provided as-is and users are encouraged to review this script in its entirety prior to utilization to ensure it will not cause impact on any computer or organization.  
The SHA256 check included in the script is not fool proof, users should check the script thoroughly before leveraging.  
This script was written and developed from an internal need and published in support of the greater IT Ecosystem.  It is in no way directly related to Sysmon from Sysinternals, 
Microsoft or any of its related products or subsidiaries.


---Script outline---
setup log file
download from Totem Github
SHA256 check
check versioning install as needed, update config regardless
modify secpol
setup schedule tasks
exit

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

https://github.com/MicrosoftDocs/sysinternals/blob/main/sysinternals/downloads/sysmon.md
https://github.com/totemtechnologies/Sysmon-Tools
https://www.jamesgibbins.com/posts/sysmon-install/

Version 1.3.5

v 1.3.5 - New deepclean system to remove all traces of broken Sysmon thanks to JAMES GIBBINS blog post.  Gramatical fixes (like someone will read the log??).  
Seeing occasional issue where the sysman script is being deleted along with the logpull script.  Theres nothing in here requiring that.  Thinking its an over-writing issue so adding some start-sleeps to mitigate.  unable to replicate further.

v 1.3.0 - Implemented new zip file extraction technique to remediate the http download issues.  Fixed original install checks. Wide spread improvements and updates.  Cleaned up script and made more efficient

v 1.2.6 - fixed updating, still having issues with HTTP.  

v 1.2.5 - added opensource warning; rebranded to avoid naming issues.  Minor cleanup

v 1.2.0 - added SHA256 Check against provided SHA256 txt file

v 1.1.6 - Minor clean up and corrections

v 1.1.5 - Created scheduled task for regular updating and log pull
    Moved execution policy to task scheduler.  
    setup transcription of output, its not ideal but its what was needed. Will make it prettier later.
    the tasks within scheduler do not update the "last run result" field.  in the history it does show a run though.  will look into later

v 1.1 -  Created foundation for installer log, to be implemented at a later date  
    Improved installer flow 
    Added check for running as an admin
    Minor typo fixes
    Changed name to Sysmon_setup

v 1.0.1 - Minor corrections to initial release

v 1.0 - initial release

#>

$SysLog = 'Sysmon Logs'
$Folder = 'C:\Windows\logs\sysmon logs'
$syslogout =  'C:\Windows\Logs\Sysmon Logs\totem_sysman.log'

#Set-ExecutionPolicy -ExecutionPolicy bypass -force

Write-host " "
Start-Transcript -append $syslogout -Force
Write-host " "
Write-host "####################################################################################"
Write-host " "
function Get-TimeStamp {return "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)}
Write-Output "$(Get-TimeStamp)"
Write-Output "starting Syslog installer/update file" #| Out-File -filepath $syslogout -NoClobber -append
Write-host " "

##Wait how old is the existing log if there is one??##

#Test to see if folder [$Folder] exists...
if (Test-Path -Path $Folder) {
    Write-host "Sysmon Log folder is present"
    Get-ChildItem –Path "$syslogout" -Recurse | Where-Object {($_.LastWriteTime -lt (Get-Date).AddDays(-30))} | Remove-Item
} else {
    Write-host "Sysmon log folder is not present"
    New-Item -ItemType Directory -path C:\Windows\Logs -name $syslog
    Write-host "created"
    }

Write-host " "

function Test-Administrator  
{  
    $user = [Security.Principal.WindowsIdentity]::GetCurrent();
    (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)  
}
If (Test-Administrator) {
    Write-Host "User is running as an admin"
    } else {
    Write-Host "User is not running as an admin, exiting" -ForegroundColor Red
    Write-host " "
    Write-host "####################################################################################"
        stop-transcript
    Exit
    }
Write-host " "

#download from sysinternals github and check if its installed, if not, do the thing.
    Write-host "downloading sysmon"
    Write-host " "
    Invoke-WebRequest 'https://live.sysinternals.com/Sysmon64.exe' -outfile "C:\Windows\Temp\sysmon64.exe" 
        
    #Configfile for HBA
    Write-host "Getting config file"
    Write-host " "
    Invoke-WebRequest 'https://raw.githubusercontent.com/totemtechnologies/Sysmon-Tools/main/sysmonconfig-export.xml' -outfile "C:\Windows\sysmonconfig-export.xml"     
    $conf = "c:\windows\sysmonconfig-export.xml"
       
    If (Test-Path C:\Windows\sysmon64.exe){

        Write-host "Sysmon is already installed"
        Write-host " " 

        } else {

        Write-host "Installing Sysmon"
        write-host " "
        Start-Process -wait -FilePath "C:\Windows\Temp\sysmon64.exe" -ArgumentList "-accepteula -i $conf"
        Write-host "Install Successful"
        }
start-sleep -Seconds 1
Invoke-WebRequest 'https://github.com/totemtechnologies/Sysmon-Tools/raw/main/Sysmon%20Updater.zip' -outfile 'C:\windows\Logs\Sysmon Logs\SysmonUpdater.zip'
Invoke-WebRequest 'https://raw.githubusercontent.com/totemtechnologies/Sysmon-Tools/main/Sysmonlog_pull.xml' -outfile 'C:\windows\Logs\Sysmon Logs\Sysmonlog_pull.xml'
Invoke-WebRequest 'https://raw.githubusercontent.com/totemtechnologies/Sysmon-Tools/main/syshash_sha256.txt' -OutFile 'C:\windows\Logs\Sysmon Logs\syshash_sha256.txt'
Invoke-WebRequest 'https://raw.githubusercontent.com/totemtechnologies/Sysmon-Tools/main/sysmon_updatecheck.xml' -outfile 'C:\windows\Logs\Sysmon Logs\sysmon_updatecheck.xml'
start-sleep -Seconds 1
expand-archive 'C:\windows\Logs\Sysmon Logs\SysmonUpdater.zip' -DestinationPath 'C:\windows\Logs\Sysmon Logs\Sysmon Updater' -force 
start-sleep -Seconds 1
move-item -Path 'C:\WINDOWS\Logs\Sysmon Logs\Sysmon Updater\Sysmon Updater\Totem_SysMan.ps1' -Destination 'C:\windows\Logs\Sysmon Logs\' -Force
move-item -Path 'C:\WINDOWS\Logs\Sysmon Logs\Sysmon Updater\Sysmon Updater\SysmonLogpull.ps1' -Destination 'C:\windows\Logs\Sysmon Logs\' -Force
start-sleep -Seconds 1

## Variables in call ##

    $file = "C:\windows\Logs\Sysmon Logs\totem_sysman.ps1"
    $CurVer = ((Get-Item 'C:\Windows\sysmon64.exe').VersionInfo)
    $newver = ((Get-Item 'c:\windows\temp\sysmon64.exe').VersionInfo)
    $hashSrc = Get-FileHash $file -Algorithm SHA256
    $hashDest = get-content -Path "C:\windows\Logs\Sysmon Logs\syshash_sha256.txt"
    $logpath = 'C:\windows\logs\sysmon logs'
    $start = (Get-Date).addMinutes(-1440)
    $Events = 22,3,1
    $logfilehost = hostname

##SHA 256 Check
Write-host "doing SHA256 check"
<#
    If ($hashSrc.Hash -ne $hashDest)
    {
      write-host "The file that was downloaded doesnt match the provided SHA256.  Something is wrong so Im taking the exit ramp now.... " -ForegroundColor Red
      exit

    } else {
    write-host "Source file and hash are equal, carrying on" -ForegroundColor Yellow
    write-host " "
    }

#>
#Version Check and update config if current
Write-host "doing sysmon version check"
    If ($curver.FileVersion -lt $newver.FileVersion){
        
        Write-Host "Current sysmon is out of date" -ForegroundColor Yellow
        Write-host " "
        Start-Process -wait -FilePath "c:\windows\temp\sysmon64.exe" -ArgumentList "-u force"
        start-sleep -Seconds 1
        Remove-Item -Path c:\windows\sysmon64.exe -Force -Recurse -ErrorAction SilentlyContinue
        start-sleep -Seconds 1
        #Uninstall Check, remove by force if necessary        
        Write-Host "Sysmon was just uninstalled, is sysmon64.exe present in the windows folder?"
            If(test-path C:\Windows\sysmon64.exe){
                
                Write-Host "yes its still present, something is wrong.  Stopping here to avoid corruption" -ForegroundColor Red
                    start-sleep -seconds 5
                    clear
                    Write-Host " "
                    Write-Host "Due to an uninstall issue with sysmon, a deep clean is neccesary.  After this, a restart is REQUIRED" -ForegroundColor Red
                    #https://www.jamesgibbins.com/posts/sysmon-install/
                    #pause 
                
                $log_file = 'c:\windows\temp\sysmon-uninstall.log'

                $items = @(
                    "C:\Windows\Sysmon64.exe",
                    "C:\Windows\SysmonDrv.sys",
                    "HKLM:\SYSTEM\CurrentControlSet\Services\Sysmon64",
                    "HKLM:\SYSTEM\CurrentControlSet\Services\SysmonDrv",
                    "HKLM:\SYSTEM\ControlSet001\Services\Sysmon64",
                    "HKLM:\SYSTEM\ControlSet001\Services\SysmonDrv",
                    "HKLM:\SYSTEM\ControlSet002\Services\Sysmon64",
                    "HKLM:\SYSTEM\ControlSet002\Services\SysmonDrv",
                    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Sysmon/Operational",
                    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Publishers\{5770385f-c22a-43e0-bf4c-06f5698ffbd9}",
                    "HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Microsoft-Windows-Sysmon-Operational"
                )

                $services = @(
                    "Sysmon64",
                    "SysmonDrv"
                )

                foreach ( $i in $items ) {
                    $error.Clear();
                    Remove-Item -Path $i -Force -Recurse -ErrorAction SilentlyContinue
                    If($error) {
                        $result = $error.Exception.Message
                    } Else {
                        $result = "O : $i"
                    }
                    Write-Output "$result".ToString() | Out-File -Filepath $log_file -Append -NoClobber -Encoding UTF8
                }
                
                foreach ( $s in $services ) {
                    $status = (Get-Service $s -ErrorAction SilentlyContinue).Status
                    Write-Output "$status : $s".ToString() | Out-File -Filepath $log_file -Append -NoClobber -Encoding UTF8
                }

                clear
                Write-host ""
                ##clean up the mess##
                Write-host "Doing a little cleanup"
                Write-host " "
                Remove-Item 'C:\WINDOWS\Logs\Sysmon Logs\Sysmon Updater' -Recurse -Force
                Remove-Item 'C:\WINDOWS\Logs\Sysmon Logs\SysmonUpdater.zip' -Recurse -Force
                Write-host ""
                Write-host "We have completed a deep-clean of Sysmon.  After restart, please navigate to <c:\windows\> and delete <sysmon64.exe> then restart <C:\windows\Logs\Sysmon Logs\totem_sysman.ps1> as an admin."
                write-host ""
            
                exit
            }
        } else {
        start-sleep -Seconds 1
        write-host "Current version is installed" -ForegroundColor Green
        Write-host " "
        Start-Process -wait -FilePath "c:\windows\temp\sysmon64.exe" -ArgumentList "-accepteula -c $conf"
        write-host "Configuration updated..." -ForegroundColor Yellow
        Write-host " "
        }
            
start-sleep -Seconds 1
##clean up the mess##
    Write-host "Doing a little cleanup"
    Write-host " "
    Remove-Item 'C:\WINDOWS\Logs\Sysmon Logs\Sysmon Updater' -Recurse -Force
    Remove-Item 'C:\WINDOWS\Logs\Sysmon Logs\SysmonUpdater.zip' -Recurse -Force

#LinusTechTips
#Modify SecPol to support
start-sleep -Seconds 1
    Write-host "Modifying secpol configuration to support better sysmon output"
    Write-host " "
    secedit /export /cfg c:\secpol.cfg
     (gc C:\secpol.cfg).replace("AuditProcessTracking = 0", "AuditProcessTracking = 3") | Out-File C:\secpol.cfg
     secedit /configure /db c:\windows\security\local.sdb /cfg c:\secpol.cfg /areas SECURITYPOLICY
     rm -force c:\secpol.cfg -confirm:$false

##Create the scheduled task to run this script at a regular cadence
start-sleep -Seconds 1
    Write-host "Getting latest updater script"
    Write-host " "

    $taskname = "Sysmon Update Check"
    if (Get-ScheduledTask | Where-Object {$_.TaskName -like $taskName }) {
    Write-Host "update Task is already setup"
    Write-host " "
    } else {
    Write-host "Setting up scheduled updater task"
    Write-host " "

    Register-ScheduledTask -xml (Get-Content 'C:\windows\Logs\Sysmon Logs\sysmon_updatecheck.xml' | Out-String) -TaskName "Sysmon Update Check" -Force

    }

    Register-ScheduledTask -xml (Get-Content 'C:\windows\Logs\Sysmon Logs\SysmonLog_Pull.xml' | Out-String) -TaskName "Sysmon Log Pull" -Force

Write-host " "
Write-host "####################################################################################"

stop-transcript
